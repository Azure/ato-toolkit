# Change log for AuditSystemDsc

## Unreleased

## 1.1.0

* Added NameSpace parameter to AuditSetting [#8](https://github.com/jcwalker/AuditSystemDsc/issues/8)
* Add example demonstrating how to assert service pack level.

## 1.0.0

* Initial release with DSC Resource AuditSetting
